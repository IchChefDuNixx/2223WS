_Exercise assignment for the course [Unsupervised and Reinforcement Learning (AAI-URL)](https://inf-git.fh-rosenheim.de/aai-url/hsro-aai-url-github-io) in the [Bachelor of AAI](https://www.th-rosenheim.de/en/technology/computer-science-mathematics/applied-artificial-intelligence-bachelors-degree) at [Rosenheim University of Applied Sciences](http://www.th-rosenheim.de)_

# Assigment 07 - Autoencoder

> As usual: The solution is available in branch "musterloesung"!

## Task 1: Autoencoder basics

For this week, you will create an autoencoder for the CIFAR10 dataset. You are free to choose the architecture of your autoencoder provided that the output image has the same dimensions as the input image.

After training, your model should meet loss and accuracy requirements when evaluated with the test dataset.

Let's begin!

To download the dataset, you can use Tensorflow:

```python
import tensorflow as tf
import tensorflow.keras.datasets.cifar10 as c10
(x_train, y_train), (x_test, y_test) = c10.load_data();
```

The CIFAR 10 dataset already has train and test splits and you can use those in this exercise. 

Here are the general steps:

1) Load the train/test split. 
2) Normalize the pixel values to the range [0,1], then return image, image pairs for training instead of image, label. This is because you will check if the output image is successfully regenerated after going through your autoencoder.
3) Shuffle the train set. 
4) Create the autoencoder model. I leave it to you which model architecture you are going to use. Pick one from the lectures. In general, you will want to downsample the image in the encoder layers then upsample it in the decoder path. Note that the output layer should be the same dimensions as the original image. Your input images will have the shape (32, 32, 3). If you deviate from this, your model may not be recognized by the grader and may fail.
5) Compile and train the model.
6) Display the results.

Good luck!

## Task 2: Autoencoder for Anomalies

### a)

Read through the https://anomagram.fastforwardlabs.com/#/ anomalie detection of fastforwardlabs.

### b)

On https://anomagram.fastforwardlabs.com/#/train trz to find a set of hyper-parameter which seem to work best.

### c)

Download the dataset from here: http://www.timeseriesclassification.com/description.php?Dataset=ECG5000 

and try to rebuild the Autoencoder using Tensorflow in a Jupyter Notebook and apply to the ECG data.
