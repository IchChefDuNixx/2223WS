_Exercise assignment for the course [Unsupervised and Reinforcement Learning (AAI-URL)](https://inf-git.fh-rosenheim.de/aai-url/hsro-aai-url-github-io) in the [Bachelor of AAI](https://www.th-rosenheim.de/en/technology/computer-science-mathematics/applied-artificial-intelligence-bachelors-degree) at [Rosenheim University of Applied Sciences](http://www.th-rosenheim.de)_

# Assigment 03 - Python, Normalization, and Clustering Applications

> As usual: The solution is available in branch "musterloesung"!

## Task 1: Python katas (as usual!)

### a) Build your own `make_blob`

We have used the scikit-learn `make_blobs` function already to create datasets for clustering. The function `make_blobs` provides great control regarding the centers and standard deviations of each cluster and is used to demonstrate clustering.

Now, let's see if we can write our own.

The signature of the function looks like the following and should return an array with n_samples data points of shape(n_features) clustered around the n_centers.

```python
 make_blobs(n_samples=100, n_features=2, n_centers=3)
```

with

- `n_samples` : int, default=100 (min value 100): It is the total number of points equally divided among clusters.
- `n_features`: int, default=2   (min value 2)  : The number of features for each sample.
- `n_centers` : int, default=3   (main value 2) : The number of centers to generate.

>Be creative in terms of distributing data points!!!

Test your function with:
- make_blobs(1000, 2, 3)
- make_blobs(0, 0, 0)  -> min values not satisfied
- make_blobs(1000, 10, 4)
- make_blobs(10000, 3, 5)

And visualize it!

### b) Test your `make_blobs`

Test your function with k-means, AgglomerativeClustering, and DBSCAN! Do the algorithms find the correct clustering?

## Task 2: Write your own Scaler

### 1) Write your own `MinMaxScaler`

Write a function `MinMaxScaler`which scales a given array of int values. Compare your result with the MinMAxScaler provided by scikit package.

### 2) Write your own `StandardScaler`

Write a function `StandardScaler`which scales a given array of int values. Compare your result with the StandardScaler provided by scikit package.


## Task 3: Clustering with more real data

This time we are using the original wine dataset: `./wine.csv`. You can find the description of the data columns here: `./wines.names`.

1.) Read the data.
2.) Normalize the data by trying different scalers.
3.) Find the clusters and compare them with the result of the last assignment.

## Task 4: Encoding

Give are the following datasets:

```
d = ['male', 'female', 'male', female', 'female', 'male', female']

e = [['dark', 'big'], ['light', 'small'], ['dark', 'normal'], ['light', 'big'], ['dark', 'big'], ['light', 'big'], ['light', 'small']]
```

Encode the datasets with LabelEncoding and One-Hot-Encoding!

### 1) Write your own `LabelEncoder`

### 2) Write your own `One-Hot Encoder`

Validate the result with the provided encoder from scikit learn.
