_Exercise assignment for the course [Unsupervised and Reinforcement Learning (AAI-URL)](https://inf-git.fh-rosenheim.de/aai-url/hsro-aai-url-github-io) in the [Bachelor of AAI](https://www.th-rosenheim.de/en/technology/computer-science-mathematics/applied-artificial-intelligence-bachelors-degree) at [Rosenheim University of Applied Sciences](http://www.th-rosenheim.de)_

# Assigment 01 - Python, Elbow method, and Hierarchical Clustering

> As usual: The solution is availabe in branch "musterloesung"!

## Task 1 - Python coding katas

a) **Sum of Pairs**

Given a list of integers and a single sum value, return the first two values (parse from the left please) in order of appearance that adds up to form the sum.

If there are two or more pairs with the required sum, the pair whose second element has the smallest index is the solution.

```python
sum_pairs([11, 3, 7, 5],         10)
#              ^--^      3 + 7 = 10
== [3, 7]

sum_pairs([4, 3, 2, 3, 4],         6)
#          ^-----^         4 + 2 = 6, indices: 0, 2 *
#             ^-----^      3 + 3 = 6, indices: 1, 3
#                ^-----^   2 + 4 = 6, indices: 2, 4
#  * the correct answer is the pair whose second value has the smallest index
== [4, 2]

sum_pairs([0, 0, -2, 3], 2)
#  there are no pairs of values that can be added to produce 2.
== None/nil/undefined (Based on the language)

sum_pairs([10, 5, 2, 3, 7, 5],         10)
#              ^-----------^   5 + 5 = 10, indices: 1, 5
#                    ^--^      3 + 7 = 10, indices: 3, 4 *
#  * the correct answer is the pair whose second value has the smallest index
== [3, 7]
```

b) **Sum of the first nth term of Series**

Your task is to write a function that returns the sum of the following series up to nth term(parameter).

Series: 1 + 1/4 + 1/7 + 1/10 + 1/13 + 1/16 +...

Rules:
- You need to round the answer to 2 decimal places and return it as String.
- If the given value is 0 then it should return 0.00
- You will only be given Natural Numbers as arguments.

Examples:(Input --> Output)
```
1 --> 1 --> "1.00"
2 --> 1 + 1/4 --> "1.25"
5 --> 1 + 1/4 + 1/7 + 1/10 + 1/13 --> "1.57"
```


## Task 2 - Elbow method and Silhouette score

To apply the K-means clustering algorithm, let's load the Palmer Penguins dataset, choose the columns that will be clustered, and use some libs to plot a scatterplot with color-coded clusters.

Download the dataset from here: https://gist.github.com/slopp/ce3b90b9168f2f921784de84fa445651

Let's import some libraries and load the Penguins dataset, trimming it to the chosen columns and dropping rows with missing data (there were only 2):

```python
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

df = pd.read_csv('penguins.csv')
print(df.shape)

df = df[['bill_length_mm', 'flipper_length_mm']]
df = df.dropna(axis=0)
```

Write some code to identify k using the Elbow method and Silhouette score from the lecture.

NOTE: You can simply pass df to KMeans as values!

## Task 3 - Hierarchical Clustering

Let’s take a look at a concrete example of how we could go about labeling data using **hierarchical agglomerative clustering**.

In this tutorial, we use the csv file containing a list of customers with their gender, age, annual income, and spending score. Use the mall customers' data from here: https://inf-git.fh-rosenheim.de/aai-url/01_exercise/-/blob/main/data.csv

Also, use the following imports:

```python
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.cluster import AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram, linkage
```

a) Load data

Load the data from the file by using the pandas `read_csv` method and use only columns 3 and 4 by using this expression

```python
X = dataset.iloc[:, [3, 4]].values
```

b) Find k

Try to find k by using either the Elbow method or the Silhouette score

c) Compare linkage

Create clusters using Agglomerative Clustering and k from b for various linkages: 'ward', 'complete', 'average', and 'single'.

Compare the results. Which one is the best?
