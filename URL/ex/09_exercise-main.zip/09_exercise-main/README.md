_Exercise assignment for the course [Unsupervised and Reinforcement Learning (AAI-URL)](https://inf-git.fh-rosenheim.de/aai-url/hsro-aai-url-github-io) in the [Bachelor of AAI](https://www.th-rosenheim.de/en/technology/computer-science-mathematics/applied-artificial-intelligence-bachelors-degree) at [Rosenheim University of Applied Sciences](http://www.th-rosenheim.de)_

# Assigment 09 - Reinforcement Learning (Part II)

> **Not** as usual: The solution is linked direclty!

## Aim of the exercise

This is again about Policy and Value Iteration using Dynamic Programming for repetition.

The objectives are:

- Understand the difference between Policy Evaluation and Policy Improvement and how these processes interact.
- Understand the Policy Iteration Algorithm
- Understand the Value Iteration Algorithm
- Understand the limitations of DP approaches

---

## Notes

- **Dynamic programming (DP)** methods assume that we have a perfect model of the Markov decision process (MDP) of the environment. This is usually not the case in practice.
- **Policy Evaluation**: Computes the value function V(s) for a policy. In each _state_, we look at for each possible _action_ and _state_ one step ahead. We can only do this because we have a perfect model of the environment.
- **Policy Improvements**: Given the correct Value Function for a Policy, we can proceed greedy with respect to it (i.e., choose the best _Action_ for each _State_). This allows us to improve the policy or keep it stable if it is already optimal.
- **Policy Iteration**: Iteratively perform policy evaluation and policy improvement until the optimal policy is reached.
- **Value Iteration**: Rather than performing multiple steps of Policy Evaluation to find the "right" V (s). In practice, this converges faster.


Note: For the tasks, you need the [Gridworld.py](gridworld.py) class. This can easily be placed in parallel with the notebook in the same directory.

**GridWorld environment**

    You are an agent on an MxN grid and your goal is to reach the terminal
    state at the top left or the bottom right corner.

    For example, a 4x4 grid looks as follows:

    T  o  o  o
    o  x  o  o
    o  o  o  o
    o  o  o  T

    x is your position and T are the two terminal states.

    You can take actions in each direction (UP=0, RIGHT=1, DOWN=2, LEFT=3).
    Actions going off the edge leave you in your current state.
    You receive a reward of -1 at each step until you reach a terminal state.

---

## Task 1

Implement the Policy Evaluation in the Python Notebook for the Gridworld Environment:

- [Exercise](Policy_Evaluation.ipynb)
- [Solution](Policy_Evaluation_Solution.ipynb)

## Task 2

Implement the policy iteration in the Python Notebook for the Gridworld Environment:

- [Exercise](Policy_Iteration.ipynb)
- [Solution](Policy_Iteration_Solution.ipynb)

## Task 3

Implement Value Evaluation in the Python Notebook for the Gridworld Environment:

- [Exercise](Value_Iteration.ipynb)
- [Solution](Value_Iteration_Solution.ipynb)
