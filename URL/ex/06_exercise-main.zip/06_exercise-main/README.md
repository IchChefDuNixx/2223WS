_Exercise assignment for the course [Unsupervised and Reinforcement Learning (AAI-URL)](https://inf-git.fh-rosenheim.de/aai-url/hsro-aai-url-github-io) in the [Bachelor of AAI](https://www.th-rosenheim.de/en/technology/computer-science-mathematics/applied-artificial-intelligence-bachelors-degree) at [Rosenheim University of Applied Sciences](http://www.th-rosenheim.de)_

# Assigment 06 - t-SNE and more

> As usual: The solution is available in branch "musterloesung"!

## Task 1: Python (as usual)

In t-SNE we are using Student t-distrubution instead of Gaussian distribution:

![grafik.png](./grafik.png)

a) Plot both distributions in one diagram for comparison.

b) Try to explain why Student t-distrubution works better for dimension reduction.

## Task 2: Some work with t-SNE and PCA

a) **Compare t-SNE with PCA: Run on a given data set PCA and t-SNE and compare the results.** Please plot your results like this

![grafik-1.png](./grafik-1.png)

![grafik-2.png](./grafik-2.png)

and

![grafik-3.png](./grafik-3.png)

![grafik-4.png](./grafik-4.png)

Use the following imports and dataset:

```python
import numpy as np
import pandas as pd
from time import time

# Packages to perform dimensionality reduction
import sklearn.datasets
import sklearn.decomposition
import sklearn.manifold

# Packages for plotting
import matplotlib.pyplot as plt
from matplotlib import offsetbox
# Load the data from sklearn (number 0 to 5 only)
digits = sklearn.datasets.load_digits(n_class=6)

# Store the data and targets
digit_images = digits.data
digit_classes = digits.target

# The data are rows of pixel values, and each pixel value is a feature (64 pixels in an 8x8 image).
n_samples, n_features = digit_images.shape

# Take a look at the data
n_img_per_row = 20
img = np.zeros((10 * n_img_per_row, 10 * n_img_per_row))
for i in range(n_img_per_row):
    ix = 10*i + 1
    for j in range(n_img_per_row):
        iy = 10*j + 1
        img[ix:ix + 8, iy:iy + 8] = digit_images[i * n_img_per_row + j].reshape((8,8))
        
plt.imshow(img, cmap=plt.cm.binary)
plt.xticks([])
plt.yticks([])
plt.title('A selection from the 64-dimensional digits dataset');
```

Use this function for plotting:

```python
def plot_embedding(embed, title=None, show_classes=True, show_examples=True):
    # Determine range of values of embedded points
    x_min, x_max = np.min(embed, 0), np.max(embed, 0)
    # Scale all points between 0 and 1
    scaled_embed = (embed - x_min) / (x_max - x_min)
    
    # Instantiate figure
    plt.figure()
    ax = plt.subplot(111)
    
    if show_classes:
        # Color each number differently (shows how we expect data to cluster)
        for i in range(scaled_embed.shape[0]):
            plt.plot(scaled_embed[i,0], scaled_embed[i,1], '.',
                     color = plt.cm.Set1(digit_classes[i]/10))
    else:
        plt.plot(scaled_embed[:,0], scaled_embed[:,1], '.k')
    
    if show_examples:
        if hasattr(offsetbox, 'AnnotationBbox'):
            # Only print thumbnail with matplotlib > 1.0;
            # initialize shown_images array
            shown_images = np.array([[1, 1]])

            # Iterate through the number of digits we imported
            for i in range(digits.data.shape[0]):
                dist = np.sum((scaled_embed[i] - shown_images) **2, 1)
                # Don't put thumbnails too close together
                if np.min(dist) < 4e-3:
                    continue
                # Concatenate the  locations of the images to be plotted
                shown_images = np.r_[shown_images, [scaled_embed[i]]]
                # Define the grayscale image of the number
                imagebox = offsetbox.AnnotationBbox(
                    offsetbox.OffsetImage(digits.images[i], cmap=plt.cm.gray_r),
                    scaled_embed[i])
                ax.add_artist(imagebox)
                
    # Remove x and y ticks
    plt.xticks([]), plt.yticks([])
    if title is not None:
        plt.title(title)
```

b) **Vary the paramters (perplexity and random_state) for t_SNE and compare the results. Which one works best and why?**

## Task 3: More  math :-) on Covariance

The covariance matrix is a math concept that occurs in several areas of machine learning. If you have a set of n numeric data items, where each data item has d dimensions, then the covariance matrix is a d-by-d symmetric square matrix where there are variance values on the diagonal and covariance values off the diagonal.

Suppose you have a set of n=5 data items, representing 5 people, where each data item has a height (X), test score (Y), and age (Z) (therefore d = 3):

```
        X      Y     Z
       height score  age
       64.0   580.0  29.0
       66.0   570.0  33.0
       68.0   590.0  37.0
       69.0   660.0  46.0
       73.0   600.0  55.0
```

a) Calculate the mean of each column by hand

b) Calculate the covariance by hand

c) Write a short Python programm and validate your result
