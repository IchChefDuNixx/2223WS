_Exercise assignment for the course [Unsupervised and Reinforcement Learning (AAI-URL)](https://inf-git.fh-rosenheim.de/aai-url/hsro-aai-url-github-io) in the [Bachelor of AAI](https://www.th-rosenheim.de/en/technology/computer-science-mathematics/applied-artificial-intelligence-bachelors-degree) at [Rosenheim University of Applied Sciences](http://www.th-rosenheim.de)_

# Assigment 02 - Python, Neighborhood, and DBSCAN

> As usual: The solution is available in branch "musterloesung"!

## Task 1 - Python coding katas

### a) Find Three Largest Numbers

Write a function that takes in an array of at least three integers and, without sorting the input array, returns a sorted array of the three largest integers in the input array. The function should return duplicate integers if necessary.

**Rules**

- The input array should have at least three integers. If it does not, you should return a null value.
- You may not sort the input array
- The function should handle duplicate integers; for example [10, 5, 9, 10, 12] should return [10, 10, 12]
- Constant space -> you will return a new array of 3 integers, and this will be the only new data structure you create.
- Linear time -> you should solve this problem by only passing through the array a single time.

**Examples**

```python
findThreeLargestNumbers([141, 1, 17, -7, -17, -27, 18, 541, 8, 7, 7]) -> [18, 141, 541]
findThreeLargestNumbers([11, -7, 5]) -> [-7, 5, 11]
findThreeLargestNumbers([1]) -> Null
```

### b) Longest Peak

Write a function that takes in an array of integers and returns the length of the longest peak in the array.

A peak is defined as adjacent integers in the array that are *strictly* increasing until they reach a tip (the highest value in the peak), at which point they become *strictly* decreasing. At least three integers are required to form a peak. 

I will make this abundantly clear in the examples.

**Rules**

1. A peak *must* increase and then decrease. 
2. The input can be an empty array, and must be an array of integers.
2. If equal value numbers appear in the run of a peak, the peak is stopped and restarted.
3. A peak must contain at least 3 numbers, such as 1,2,1
4. Numbers can be positive or negative.
5. *Bonus:* Optimal time and space: O(n) time | O(1) space - where n is the length of the input array.

**Examples**

```python
longest_peak([5, 4, 3, 2, 1]) -> 0 # all decreasing
longest_peak([1, 2, 3, 4, 5]) -> 0 # all increasing
longest_peak([5, 4, 3, 2, 1, 2, 10, 12]) -> 0 # all decreasing, then all increasing
longest_peak([]) -> 0 # empty input check mandatory :D
longest_peak([1, 3, 2]) -> 3 # normal peak
longest_peak([1, 2, 3, 4, 5, 1]) -> 6 # peak ends on last number
longest_peak([2, 2, 3, 2]) -> 3 # repeat at the beginning
longest_peak([1, 2, 3, 2, 1, 1]) -> 5 # repeat at the end
longest_peak([1, 2, 3, 3, 2, 1]) -> 0 # equality at peak tip, 0 is returned
longest_peak([1, 1, 1, 2, 3, 10, 12, -3, 2, 3, 45, 800, 99, 98, 0, -1, 2, 3, 4, 5, 0, -1]) -> 9 # peak in the middle -3, 2, 3, 45, 800, 99, 98, 0, -1
```

## Task 2 - DBSCAN

Given the following data set:

![image.png](./image.png)

As a distance function, use Manhattan Distance:

L1(x, y) = |x1 − y1| + |x2 − y2|


Compute DBSCAN and indicate which points are core points, border points, and noise points.

Use the following parameter settings:

- Radius ε = 1.1 and minPts = 2
- Radius ε = 1.1 and minPts = 3
- Radius ε = 1.1 and minPts = 4
- Radius ε = 2.1 and minPts = 4
- Radius ε = 4.1 and minPts = 5
- Radius ε = 4.1 and minPts = 4

## Task 3 - Comparing DBSCAN with k-means and Hierarchical Clustering

In this task, we attempted to group different wines using k-means, hierarchical clustering, DBSCAN.

The story: You are managing store inventory and have received a large shipment of wine, but the brand labels fell off the bottles during transit. Fortunately, your supplier provided you with the chemical readings for each bottle along with their respective serial numbers. 

Unfortunately, you aren't able to open each bottle of wine and taste test the difference – you must find a way to group the unlabeled bottles back together according to their chemical readings! You know from the order list that you ordered three different types of wine and are given only two wine attributes to group the wine types back together.

Find out which clustering works best. Can you achieve as silhouette score of something better than 0.59.

>Use scikit-learn kmeans, AgglomerativeClustering and DBSCAN.

These steps will help you to complete the activity:

1. Import the necessary packages.
2. Load the wine dataset (provided within this repo: [wine.csv](./wine.csv)) and check what the data looks like (short description is within [wine.names](./wine.names)).
3. Visualize the data.
4. Generate clusters using k-means, agglomerative clustering, and DSBSCAN.
5. Evaluate a few different options for DSBSCAN hyperparameters and their effect on the silhouette score.
6. Generate the final clusters based on the highest silhouette score.
7. Visualize clusters generated using each of the three methods.
