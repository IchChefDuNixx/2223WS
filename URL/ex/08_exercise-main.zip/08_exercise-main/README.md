_Exercise assignment for the course [Unsupervised and Reinforcement Learning (AAI-URL)](https://inf-git.fh-rosenheim.de/aai-url/hsro-aai-url-github-io) in the [Bachelor of AAI](https://www.th-rosenheim.de/en/technology/computer-science-mathematics/applied-artificial-intelligence-bachelors-degree) at [Rosenheim University of Applied Sciences](http://www.th-rosenheim.de)_

# Assigment 08 - Reinforcement Learning

> As usual: The solution is available in branch "musterloesung"!

## Aim of the exercise

- n-armed bandit problem
- Setup OpenAI Gym environments and test a simple example
- Setup with another OpenAI environment and test with random policy

---

## Task 1

In the lecture we have learned about n-armed bandit problem with Q-Learning approach.

**Epsilon-Greedy Action Selection**
Epsilon-Greedy is a simple method to balance exploration and exploitation by choosing between exploration and exploitation randomly. The epsilon-greedy, where epsilon refers to the probability of choosing to explore, exploits most of the time with a small chance of exploring.

```math
with \space probablity \space 1-\epsilon : a_t = max Q_t(a)
```
```math
with \space probablity \space \epsilon   : a_t= any \space action
```

Use the [Jupyter Notebook](n-armed_Bandit.ipynb) to n-armed Bandit and compare 5 different epsilon-greedy values. Import the notebook into your environment and implement the function `epsilon_greedy_action_selection(k, numsteps, epsilon)`.

---

## Task 2

**a)**

OpenAI is a non-profit organization dedicated to the study of artificial intelligence (AI).

As of 2016, OpenAI has developed its platform "OpenAI Gym", which deals with reinforcement learning. The source code is available in its current version on GitHub (https://github.com/openai/gym). The aim is to provide a basic system that is easy to set up and supports a wide range of different development environments. OpenAI Gym thus tries to offer a standardization for the publication of results in artificial intelligence research in order to be able to compare and reproduce publications more easily.


Install the OpenAI Gym environment on your computer. Follow the instructions here: [Gym](https://github.com/openai/gym).

It may be sufficient to do a 

```bash
>pip3 install gym
```

in your Python (Anaconda) environment.

**b)**

Implement a `random_policy` function for the following environnement:

```python
env = gym.make("FrozenLake8x8-v1")
```

This is an extended Frozenlake variant!
