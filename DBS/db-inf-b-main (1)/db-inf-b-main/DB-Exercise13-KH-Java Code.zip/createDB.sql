create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table PersonenJPA (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table PersonenJPA (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table PersonenJPA (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table PersonenJPA (id numeric(19,0) identity not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table PersonenJPA (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table PersonenJPA (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table PersonenJPA (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table PersonenJPA (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table PersonenJPA (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table PersonenJPA (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table PersonenJPA (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table PersonenJPA (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table PersonenJPA (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Geburtstag datetime, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (student varbinary(255) not null, lecture varbinary(255) not null, grade double precision not null, primary key (student, lecture))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, primary key (Semester, Name))
alter table Veranstaltung add constraint FKn8u9q7m4e9jjiglkt46c6vebg foreign key (Name) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (student varbinary(255) not null, lecture varbinary(255) not null, grade double precision not null, primary key (student, lecture))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, primary key (Semester, Name))
alter table Veranstaltung add constraint FKn8u9q7m4e9jjiglkt46c6vebg foreign key (Name) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (student varbinary(255) not null, lecture varbinary(255) not null, grade double precision not null, primary key (student, lecture))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (student varbinary(255) not null, lecture varbinary(255) not null, grade double precision not null, primary key (student, lecture))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint UK_dct8g7mentunbcy7kwjwn96cs unique (student_Matrikelnummer)
alter table SinV add constraint UK_kxuljlha7nx0k4g2jguc8g3nq unique (lecture_Semester, lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
create table Dozent (Name varchar(255) not null, Buero varchar(255), Tel varchar(255), primary key (Name))
create table hibernate_sequence (next_val numeric(19,0))
insert into hibernate_sequence values ( 1 )
insert into hibernate_sequence values ( 1 )
create table Person (id numeric(19,0) not null, Vorname varchar(255), Name varchar(255), primary key (id))
create table SinV (grade double precision not null, student_Matrikelnummer int not null, lecture_Semester varchar(255) not null, lecture_Name varchar(255) not null, primary key (student_Matrikelnummer, lecture_Semester, lecture_Name))
create table Student (Matrikelnummer int not null, Geburtstag varchar(255), Name varchar(255), primary key (Matrikelnummer))
create table Student_SinV (Student_Matrikelnummer int not null, lectures_student_Matrikelnummer int not null, lectures_lecture_Semester varchar(255) not null, lectures_lecture_Name varchar(255) not null)
create table Veranstaltung (Semester varchar(255) not null, Name varchar(255) not null, Dozent varchar(255), primary key (Semester, Name))
alter table Student_SinV add constraint UK_8tm6hf4tt38ulg878syca7ib6 unique (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name)
alter table SinV add constraint FK8c7ah1tewhsmb2g8xwmtqol3j foreign key (student_Matrikelnummer) references Student
alter table SinV add constraint FKa5wl886skpl27t1yg4u5lhov2 foreign key (lecture_Semester, lecture_Name) references Veranstaltung
alter table Student_SinV add constraint FKoqfm8xepax17ab4l0q48e6tai foreign key (lectures_student_Matrikelnummer, lectures_lecture_Semester, lectures_lecture_Name) references SinV
alter table Student_SinV add constraint FKiq5r6kr4o5o62cg1g4ftbpi30 foreign key (Student_Matrikelnummer) references Student
alter table Veranstaltung add constraint FKs966hxoxfewtkf1fmrpaxr2th foreign key (Dozent) references Dozent
