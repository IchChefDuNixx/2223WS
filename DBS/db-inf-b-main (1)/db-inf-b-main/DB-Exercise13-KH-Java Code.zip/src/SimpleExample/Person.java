package SimpleExample;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "Person")
public class Person implements Serializable
{
    @Id
    @GeneratedValue
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Vorname")
    private String firstName;

    @Column(name = "Name")
    private String lastName;
    
    public Person(String firstName, String lastName)
    {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getName() { return lastName+", "+firstName; }

    @Override
    public String toString()
    {
        return "Person [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + "]";
    }

    public Long getId() {
        return id;
    }


    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
