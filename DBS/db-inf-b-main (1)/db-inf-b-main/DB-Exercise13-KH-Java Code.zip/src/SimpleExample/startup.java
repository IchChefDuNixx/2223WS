package SimpleExample;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.Iterator;
import java.util.List;

public class startup {
    public static void main(String[] args) {
        // Verbindung über die Konfiguration THRO-INF-DB herstellen
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("THRO-INF-DB");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        // .. wir erstellen einige Personen
        Person p1 = new Person("Maria", "Meier");
        Person p2 = new Person("Stefan", "Schmitt");
        Person p3 = new Person("Klaus", "Kramptner");
        Person p4 = new Person("Sabine", "Sommer");

        // und speichern die in unserer Datenbank
        em.persist(p1);
        em.persist(p2);
        em.persist(p3);
        em.persist(p4);

        // Jetzt sollten die schon ganz automatisch eine ID bekommen haben
        Long mariaId = p1.getId();
        Person maria = em.find(Person.class,mariaId);

        // Wir lassen uns alle Personen mit einem t im Nachnamen geben
        String query="SELECT p FROM Person p WHERE p.lastName LIKE '%t%'";
        TypedQuery<Person> allePersonenAbfrage = em.createQuery(query, Person.class);

        // Das übernehmen wir als Liste in unseren Code und gaben es aus.
        List<Person> allePersonen = allePersonenAbfrage.getResultList();
        Iterator<Person> personenIterator = allePersonen.iterator();
        while(personenIterator.hasNext()){
            Person p = personenIterator.next();
            System.out.println(p.getName());
        }

        // wir löschen auch mal was aus der DB, das bedeutet aber nicht, dass das
        // Objekt weg ist, allerdings schon, dass auch p1 aus der DB weg ist.
        em.remove(maria);
        System.out.println(maria.getName());
        Person gibtsNicht = em.find(Person.class, p1.getId());
        System.out.println(gibtsNicht);

        // Und dann hat die Sabine geheiratet
        // das macht dann JPA für uns
        p4.setLastName("Kramptner");

        // wir verändern aber nichmal alle Datensätze etwas
        String updateQuery="UPDATE Person p SET p.firstName=p.firstName+'_' ";
        em.createQuery(updateQuery).executeUpdate();

        // Verbindung schließen und Daten schreiben
        em.getTransaction().commit();
        em.close();
        emf.close();
    }
}
