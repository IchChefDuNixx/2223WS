package JDBCExample;

public class Auto {
    private String hersteller;
    private String name;
    private int preis;

    public Auto(String hersteller, String name){
        this.hersteller=hersteller;
        this.name=name;
        this.preis=0;
    }

    public void setPreis(int preis){
        this.preis=preis;
    }

    public String getHersteller() {
        return hersteller;
    }

    public void setHersteller(String hersteller) {
        this.hersteller = hersteller;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPreis() {
        return preis;
    }

    @Override
    public String toString(){
        return this.name + " von "+this.hersteller+" zu einem Preis von € "+this.preis;
    }
}
