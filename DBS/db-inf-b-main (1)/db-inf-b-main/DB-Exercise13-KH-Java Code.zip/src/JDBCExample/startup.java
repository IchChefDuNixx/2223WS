package JDBCExample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class startup {
    public static void main(String[] args) {
        try {
            // Wir stellen eine Verbindung her
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String username="INFUSER00";
            String password="INFUSER00";
            String connectionString=    "jdbc:sqlserver://inf-rdb01.fh-rosenheim.priv;"+
                                        "instanceName=DBINF;"+
                                        "databaseName=INFDB00;";
            Connection conn = DriverManager.getConnection(connectionString,username,password);

            // erst mal fügen wir was ein.
            conn.createStatement().execute("INSERT INTO Auto (name, hersteller, preis) values ('1er','BMW',36500)");

            // dann serialisieren wir ein Objekt.
            // das geht natürlich nur, wenn wir keinen Key verletzen.
            Auto porsche = new Auto("VW", "Porsche911RS");
            porsche.setPreis(250_000);
            String serializer = "";
            serializer =    "INSERT INTO Auto (name, hersteller, preis) values ('"+
                            porsche.getName()+ "','" +
                            porsche.getHersteller()+"',"+
                            porsche.getPreis()+")";
            conn.createStatement().execute(serializer);


            // jetzt deserialisieren iwr das Objekt. Voraussetzung ist, wir kennen
            // den Schlüssel, haben wir nicht, wir nehemn Name, Hersteller an.
            String deserializer ="";
            deserializer=   "SELECT name, hersteller, preis FROM auto WHERE "+
                            "name='Porsche911RS' AND "+
                            "hersteller='VW'";
            ResultSet result = conn.createStatement().executeQuery(deserializer);
            result.next();

            // Jetzt haben wir unseren Datensatz ausgelesen und müssen
            // Daraus noch ein Objekt machen.
            Auto neuerPorsche = new Auto(result.getString(2), result.getString(1));
            neuerPorsche.setPreis(result.getInt(3));
            System.out.println(neuerPorsche);

            // Aufgabe

            // Zu guterletzt wird die Verbindung geschlossen
            conn.close();

        }catch(Exception e){
            System.out.println(e.fillInStackTrace());
        }
    }
}

