package PizzaShop;

public class Rezept {
    private int menge;
    private Zutat zutat;

    public Rezept(int menge, Zutat zutat) {
        this.menge = menge;
        this.zutat = zutat;
    }

    public Rezept() {
    }

    public int getMenge() {
        return menge;
    }

    public void setMenge(int menge) {
        this.menge = menge;
    }

    public Zutat getZutat() {
        return zutat;
    }

    public void setZutat(Zutat zutat) {
        this.zutat = zutat;
    }
}
