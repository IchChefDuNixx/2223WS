package PizzaShop;

public class Zutat {
    private String name;
    private int kalorienPro100g;

    public Zutat(String name, int kalorienPro100g) {
        this.name = name;
        this.kalorienPro100g = kalorienPro100g;
    }

    public Zutat() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getKalorienPro100g() {
        return kalorienPro100g;
    }

    public void setKalorienPro100g(int kalorienPro100g) {
        this.kalorienPro100g = kalorienPro100g;
    }
}
