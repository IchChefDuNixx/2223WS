package PizzaShop;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class startup {
    public static void main(String[] args) {
        // Verbindung über die Konfiguration THRO-INF-DB herstellen
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("THRO-INF-DB");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();



        // Verbindung schließen und Daten schreiben
        em.getTransaction().commit();
        em.close();
        emf.close();
    }
}
