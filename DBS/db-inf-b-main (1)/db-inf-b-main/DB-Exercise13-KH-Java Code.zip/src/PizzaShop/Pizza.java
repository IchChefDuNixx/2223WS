package PizzaShop;

import java.util.ArrayList;
import java.util.List;

public class Pizza {

    private String name;
    private int preis;
    private List<Rezept> zutaten;

    public Pizza() {
    }

    public Pizza(String name, int preis) {
        this.name = name;
        this.preis = preis;
        this.zutaten= new ArrayList<Rezept>();
    }

    public List<Rezept> getZutaten() {
        return zutaten;
    }

    public void setZutaten(List<Rezept> zutaten) {
        this.zutaten = zutaten;
    }

    public void addZutat(Rezept z){
        this.zutaten.add(z);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPreis() {
        return preis;
    }

    public void setPreis(int preis) {
        this.preis = preis;
    }
}
