package StudentsAndProfessors;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "SinV")
public class Participation  implements Serializable {
    @Id
    @ManyToOne
    private Lecture lecture;

    @Id
    @ManyToOne
    private Student student;

    private double grade;

    public Participation(){}

    public Participation(Lecture lecture, Student student){
        this.lecture=lecture;
        this.student=student;
        this.student.addParticipation(this);
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }
    @Override
    public String toString(){
        return("Studierender "+this.student.toString()+ " hat in der Veranstaltung "+this.lecture.toString()+ " die Note "+this.grade+" erhalten");
    }

    public Lecture getLecture() {
        return lecture;
    }

    public void setLecture(Lecture lecture) {
        this.lecture = lecture;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
}
