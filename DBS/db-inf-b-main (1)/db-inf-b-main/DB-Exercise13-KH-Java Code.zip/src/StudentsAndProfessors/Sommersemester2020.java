package StudentsAndProfessors;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.ArrayList;
import java.util.List;

public class Sommersemester2020 {
    public static void main(String[] args) {
        // Verbindung über die Konfiguration THRO-INF-DB herstellen
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("THRO-INF-DB");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        // wir erzeugen Daten und persitieren die
        Student s1 = new Student("Klaus", "1998-11-22");
        Student s2 = new Student("Malte", "1997-01-12");
        Student s3 = new Student("Sabine", "1991-06-11");
        Student s4 = new Student("Kerstin", "1996-04-01");
        em.persist(s1);
        em.persist(s2);
        em.persist(s3);
        em.persist(s4);

        Professor p1 = new Professor("Kai", "B1.18", "12345");
        Professor p2 = new Professor("Wolfgang", "B1.12", "345678");
        Professor p3 = new Professor("Claudia", "B1.22", "9876");
        em.persist(p1);
        em.persist(p2);
        em.persist(p3);

        Lecture l1 = new Lecture(p1, "Datenbanken", "WS19");
        Lecture l2 = new Lecture(p2, "Programmieren 3", "WS19");
        Lecture l3 = new Lecture(p3, "Unternehmensgründung", "SS20");
        em.persist(l1);
        em.persist(l2);
        em.persist(l3);

        Participation sinv1 = new Participation(l1, s1);
        Participation sinv2 = new Participation(l1, s2);
        Participation sinv3 = new Participation(l1, s3);
        Participation sinv4 = new Participation(l1, s4);
        Participation sinv5 = new Participation(l2, s1);
        Participation sinv6 = new Participation(l2, s2);
        Participation sinv7 = new Participation(l2, s3);
        Participation sinv8 = new Participation(l3, s1);
        Participation sinv9 = new Participation(l3, s2);

        sinv1.setGrade(1.0);
        sinv2.setGrade(2.0);
        sinv3.setGrade(3.0);
        sinv4.setGrade(4.0);
        sinv5.setGrade(1.0);
        sinv6.setGrade(2.0);
        sinv7.setGrade(3.0);
        sinv8.setGrade(4.0);
        sinv9.setGrade(5.0);

        em.persist(sinv1);
        em.persist(sinv2);
        em.persist(sinv3);
        em.persist(sinv4);
        em.persist(sinv5);
        em.persist(sinv6);
        em.persist(sinv7);
        em.persist(sinv8);
        em.persist(sinv9);

        // wir geben mal die Lectures aus.
        s1.printLectures();

        // und jetzt geben wir mal den Median aus.

        // Wir lassen uns alle Teilnahmen geben
        String query = "SELECT t FROM Participation t ORDER BY t.grade";
        TypedQuery<Participation> teilnahmenResult = em.createQuery(query, Participation.class);
        List<Participation> teilnahmen = teilnahmenResult.getResultList();

        int mitte = (int) (teilnahmen.size() / 2);
        double median = 0.0;
        if (mitte == (teilnahmen.size() / 2)) {
            median = (teilnahmen.get(mitte).getGrade() + teilnahmen.get(mitte + 1).getGrade()) / 2;
        } else {
            median = teilnahmen.get(mitte + 1).getGrade();
        }

        System.out.println("###### Median: " + median);

        // Verbindung schließen und Daten schreiben
        em.getTransaction().commit();
        em.close();
        emf.close();
    }


}
