package StudentsAndProfessors;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Entity
@Table(name = "Student")
public class Student  implements Serializable {

    @Column(name = "Name")
    private String name;

    @Id
    @GeneratedValue
    @Column(name="Matrikelnummer")
    private int register;

    @Column(name = "Geburtstag")
    private String birthday;

    @OneToMany
    private List<Participation> lectures;

    public Student(){}

    public Student(String name, String birthday){
        this.name=name;
        this.birthday=birthday;
        this.lectures= new ArrayList<>();
    }

    @Override
    public String toString(){
        return ("Name: "+this.name+" Matrikel:"+this.register);
    }

    public void printLectures(){
        Iterator it = this.lectures.iterator();
        System.out.println("######## Teilnahmen von Matrikelnummer: "+this.register);
        while(it.hasNext()){
            System.out.println(it.next().toString());
        }
    }

    public void addParticipation(Participation p){
        this.lectures.add(p);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRegister() {
        return register;
    }

    public void setRegister(int register) {
        this.register = register;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public List<Participation> getLectures() {
        return lectures;
    }

    public void setLectures(List<Participation> lectures) {
        this.lectures = lectures;
    }
}
