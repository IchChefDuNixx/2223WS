package StudentsAndProfessors;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "Veranstaltung")
public class Lecture implements Serializable {

    @ManyToOne
    @JoinColumn(name = "Dozent")
    private Professor prof;

    @Id
    @Column(name = "Name")
    private String name;

    @Id
    @Column(name = "Semester")
    private String semester;

    public Lecture(){}

    public Lecture(Professor p, String name, String semester){
        this.prof=p;
        this.name=name;
        this.semester=semester;
    }

    @Override
    public String toString(){
        return(this.name+" im Semester "+this.semester+" wird gehalten von Prof. "+this.prof);
    }

    public Professor getProf() {
        return prof;
    }

    public void setProf(Professor prof) {
        this.prof = prof;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }
}
