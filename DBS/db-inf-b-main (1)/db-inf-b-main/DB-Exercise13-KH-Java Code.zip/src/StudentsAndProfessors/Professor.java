package StudentsAndProfessors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "Dozent")
public class Professor implements Serializable {
    @Id
    @Column(name = "Name")
    private String name;

    @Column(name = "Buero")
    private String office;

    @Column(name = "Tel")
    private String phone;

    public Professor(){}

    public Professor(String name, String office, String phone){
        this.name=name;
        this.office=office;
        this.phone=phone;
    }

    @Override
    public String toString(){
        return this.name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
